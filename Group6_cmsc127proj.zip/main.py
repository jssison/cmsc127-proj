import login

# Main func
def main():
    login.login()

# Run main
main()